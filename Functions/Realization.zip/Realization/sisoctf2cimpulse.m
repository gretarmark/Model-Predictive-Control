function [t,y]=sisoctf2cimpulse(num,den,tau,tf,npoints)





